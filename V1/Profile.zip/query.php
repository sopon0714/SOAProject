<?php

// สินค้าทั้งหมดในระบบ
function DB_ProductAll (){
    require('connect.php');
    $stmt = $con->query("SELECT * FROM `db_product`");
    return $stmt;
}

// สินค้าที่เปิดขาย
function DB_ProductStatusON(){
    require('connect.php');
    $stmt = $con->query("SELECT * FROM `db_product` WHERE `product_status` = 1");
    return $stmt;
}

// ข้อมูลผู่้ใช้
function DB_user(){
    require('connect.php');
    session_start();
    $username = $_SESSION['username'];
    $password = $_SESSION['password'];
    $stmt = $con->query("SELECT * FROM `db_user` WHERE `username` = '$username' AND `password`= '$password'");
    return $stmt;
}

function ed_user($UID,$name,$surname,$address,$tel,$email){
    // UPDATE `db_user` SET `username` = 'admin1s', `name` = 'Nipapornv', `surname` = 'Sornphommasd', `address` = '145\r\nSongphinong\r\n72110\r\nThailandsdv', `tel` = '0871145312sdv', `email` = 'nipa@gmail.comasd' WHERE `db_user`.`UID` = 2
    require('connect.php');
    $con->query("UPDATE `db_user` SET `name` = '$name', `surname` = '$surname', `address` = '$address', `tel` = '$tel', `email` = '$email' WHERE `db_user`.`UID` = '$UID'");
    session_start();
    
}


?>